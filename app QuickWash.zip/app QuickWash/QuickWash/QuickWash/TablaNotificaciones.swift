//
//  TablaNotificaciones.swift
//  QuickWash
//
//  Created by Pedro Navarrete on 25/05/21.
//

import UIKit

class TablaNotificaciones: UITableViewController {
    var titulos:[String] = []
    var descripciones:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // http://52.200.53.213:3999/notificaciones
        let liga = "http://52.200.53.213:3999/notificaciones"
        let url = NSURL(string: liga)!
        URLSession.shared.dataTask(with: url as URL) { (data, res, err) in

                guard let data = data else {
                      return
                }
            
                do {
                    let resultado = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [NSDictionary]
                    print(resultado)
                    for valor in resultado {
                        self.titulos.append(valor["titulo"] as! String)
                        self.descripciones.append(valor["descripcion"]  as! String)
                    }
                    //print(resultado)
                    print(self.titulos)
                    
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                    
                } catch {
                    print("didnt work")
                }

            }.resume()
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.titulos.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell? =
            tableView.dequeueReusableCell(withIdentifier: "celda")
        if (cell == nil)
        {
            cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle,
                        reuseIdentifier: "celda")
        }

            //cell.textLabel?.text = "Section \(indexPath.section) Row \(indexPath.row)"
        cell?.textLabel?.text = self.titulos[indexPath.row]
        cell?.detailTextLabel?.text = self.descripciones[indexPath.row]
        

        return cell!
        }
}

