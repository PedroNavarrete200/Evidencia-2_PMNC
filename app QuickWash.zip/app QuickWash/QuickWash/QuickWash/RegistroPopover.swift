//
//  RegistroPopover.swift
//  QuickWash
//
//  Created by Pedro Navarrete on 25/05/21.
//

import UIKit

class RegistroPopover: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func exitpop(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
}

